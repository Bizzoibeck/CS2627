#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

void stars(int low, int high);
void printl(int n);

int main(int argc, char **argv)
{
	int low;
	int high;

	if (argc != 3) {
		fprintf(stderr, "\nUsage: %s low high\n\n", argv[0]);
		exit(1);
	}

	low = atoi(argv[1]);
	high = atoi(argv[2]);

	stars(low, high);

	return 0;
}


void stars(int low, int high)
{
	int i = low;

	do {
		printl(i);
		i++;
	}
	while (i <= high);
}

void printl(int n)
{
	int i = n;

	do {
	write(1, "*", 1);
		i--;
	}
	while (i > 0);

	write(1, "\n", 1);
}

