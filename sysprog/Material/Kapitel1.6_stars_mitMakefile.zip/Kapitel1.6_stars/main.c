#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "stars.h"

int main(int argc, char **argv)
{
	int low;
	int high;

	if (argc != 3) {
		fprintf(stderr, "\nUsage: %s low high\n\n", argv[0]);
		exit(1);
	}

	low = atoi(argv[1]);
	high = atoi(argv[2]);

	stars(low, high);

	return 0;
}


