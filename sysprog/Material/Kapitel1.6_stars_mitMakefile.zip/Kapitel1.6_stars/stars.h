#ifndef _STARS_H
#define _STARS_H 

void stars(int low, int high);

#endif