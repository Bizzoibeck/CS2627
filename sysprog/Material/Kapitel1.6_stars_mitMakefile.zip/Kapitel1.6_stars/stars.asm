%macro write 3
    mov rax, 1
    mov rdi, %1
    mov rsi, %2
    mov rdx, %3
    syscall
%endmacro


global stars

SECTION .data
starChar: db "*"
starCharLen: equ $ - starChar
newLineChar: db 10
newLineCharLen: equ $ - newLineChar


SECTION .text

stars:
    push rbp		; set up stack frame
    mov rbp, rsp

    mov rcx, rdi	; par. low in rcx 
    mov rbx, rsi	; par. high in rbx
  outerWhile:
	mov rdi, rcx	; par. for printl
	push rcx	; rcx is caller-saved!

        call printl	; void printl(int n)

	pop rcx
        inc rcx
        cmp rbx, rcx     
        jae outerWhile
    leave
    ret


printl:
    push rbp		; set up stack frame
    mov rbp, rsp

    mov rcx, rdi	; par. n in rcx
innerWhile:
	push rcx	; rcx is caller-saved! (also macro, with syscall !)
        write 1, starChar, starCharLen
	pop rcx
        loop innerWhile
    write 1, newLineChar, newLineCharLen
    leave
    ret