; syscall "write"
%macro write 3
	mov rax, 1
	mov rdi, %1
	mov rsi, %2
	mov rdx, %3
	syscall
%endmacro

SECTION .data
hello:	db	"Registertest beendet!", 10
helloLen:	equ	$-hello

zahl1:	db	0x01			; 8 bit = byte
zahl2:	dw	0x0203			; 16 bit = word
zahl3:	dd	0x66000004		; 32 bit = double/long, dword
zahl4:	dq	0x0000007700000055	; 64 bit = quad, qword
zahl5:	dw	-1			; 16 bit
zahl6:	dq	-1			; 64 bit
zahl7:	dq	-2			; 64 bit
MAXNUM:	dq	0xFFFFFFFFFFFFFFFF	; 64 bit
MAX2:	dq	0xFEFEFEFEFEFEFEFE	; 64 bit

zahl11:	db	0x05			; 8 bit = byte	positive Zahl
zahl12:	db	-0x05			; 8 bit = byte	negative Zahl
zahl13:	dw	-0x0203			; 16 bit = word
zahl14:	dd	-0x66000004		; 32 bit = double/long, dword




global _start

SECTION .text
_start:
first:	mov rax, [zahl1]
	mov bl, byte [zahl1]
	mov cx, word [zahl5]
	mov edx, dword [zahl6]
	mov rsi, [zahl6]
	mov rdi, qword [zahl6]

	mov rax, [MAX2]
	mov rbx, [MAX2]
	mov rcx, [MAX2]
	mov rdx, [MAX2]
	mov rsi, [MAX2]
	mov rdi, [MAX2]

second: mov ah, [zahl2]
	mov al, [zahl2]
	mov bx, [zahl2]
	mov cl, [zahl2]
	mov ch, [zahl2]
	mov cx, [zahl2]
	mov ecx, [zahl2]	; !!! ecx, ebx, eax überschreibt 64 bit !!!
	mov ebx, [zahl2]
	mov eax, [zahl2]
	mov ecx, dword [zahl2]
	mov rdx, [zahl2]

	mov rax, [MAXNUM]
	mov rbx, [MAXNUM]
	mov rcx, [MAXNUM]
	mov rdx, [MAXNUM]

third:	mov ah, [zahl7]
	mov al, [zahl7]
	mov bx, [zahl7]
	mov cl, [zahl7]
	mov ch, [zahl7]
	mov cx, [zahl7]
	mov ecx, [zahl7]	; !!! ecx, ebx, eax überschreibt 64 bit !!!
	mov ebx, [zahl7]
	mov eax, [zahl7]
	mov ecx, dword [zahl7]
	mov rdx, [zahl7]

conversion:
	mov al, byte [zahl11] 
	cbw

; CBW (Convert Byte to Word): Kopiert das Vorzeichenbit des Byte-Operanden (AL) in alle Bits des AH-Registers.
; Ergebnis: Erweitert das 8-Bit-Register AL zu einem 16-Bit-Wort im AX-Register.

	mov rax, 0
	mov al, byte [zahl12] 
	cbw
; nochmal CBW

	mov rax, 0
	mov ax, word [zahl13]
	cwd
; CWD (Convert Word to Doubleword): Kopiert das Vorzeichenbit des Wortes im AX-Register in alle Bits des DX-Registers.
; Ergebnis: Erweitert das 16-Bit-Register AX zu einem 32-Bit-Doppelwort, das sich über DX:AX erstreckt.

	mov eax, 0
	mov ax, word [zahl13]
	cwde
; CWDE (Convert Word to Doubleword Extended): Kopiert das Vorzeichenbit des Wortes im AX-Register in die oberen 16 Bits des EAX-Registers.
; Ergebnis: Erweitert das 16-Bit-Register AX zu einem 32-Bit-Doppelwort im EAX-Register.

	mov eax, 0
	mov eax, dword [zahl14]
	cdqe
; CDQE (Convert Doubleword to Quadword): Kopiert das Vorzeichenbit des 32-Bit-Doppelworts im EAX-Register in die oberen 32 Bits des RAX-Registers.
; Ergebnis: Erweitert das 32-Bit-Register EAX zu einem 64-Bit-Quadwort im RAX-Register. 


	write 1, hello, helloLen
	mov rax, 60
	mov rdi, 0
	syscall

